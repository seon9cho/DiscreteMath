//
//  Tuple.h
//  Lab 3
//
//  Created by Seong-Eun Cho on 7/20/16.
//  Copyright © 2016 Seong-Eun Cho. All rights reserved.
//

#ifndef Tuple_h
#define Tuple_h
#include <vector>
#include <string>
using namespace std;

class Tuple : public vector<string> {
    
};

#endif /* Tuple_h */
