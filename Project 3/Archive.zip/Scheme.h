//
//  Scheme.h
//  Lab 3
//
//  Created by Seong-Eun Cho on 7/20/16.
//  Copyright © 2016 Seong-Eun Cho. All rights reserved.
//

#ifndef Scheme_h
#define Scheme_h
#include <vector>
#include <string>
using namespace std;

class Scheme : public vector<string> {
    
};

#endif /* Scheme_h */
